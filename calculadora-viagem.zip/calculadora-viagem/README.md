# Calculadora de Viagem

Um aplicativo web moderno que ajuda você a encontrar as melhores opções de viagem até R$ 10.000, com análise detalhada de custos, vantagens e desvantagens.

## 🌟 Funcionalidades

- **Busca Inteligente**: Digite o destino desejado e encontre opções personalizadas
- **Análise de Custos**: Visualize detalhadamente os custos de transporte, hospedagem e atividades
- **Comparação de Opções**: Compare diferentes alternativas (padrão vs econômico)
- **Pros e Contras**: Veja as vantagens e desvantagens de cada opção
- **Interface Responsiva**: Funciona perfeitamente em desktop e mobile
- **Design Moderno**: Interface limpa e intuitiva com componentes profissionais

## 🎯 Destinos Disponíveis

O aplicativo atualmente oferece opções para os seguintes destinos:

### Nacionais
- **São Paulo** - A partir de R$ 1.800
- **Rio de Janeiro** - A partir de R$ 2.200

### Internacionais
- **Buenos Aires** - A partir de R$ 3.200
- **Lisboa** - A partir de R$ 6.200
- **Tóquio** - A partir de R$ 9.800

## 💰 Tipos de Viagem

Cada destino oferece diferentes categorias:

- **Nacional**: Opções confortáveis com voo e hotel de qualidade
- **Nacional Econômico**: Alternativas mais baratas com ônibus e hostel
- **Internacional**: Viagens internacionais com conforto
- **Internacional Econômico**: Opções internacionais mais acessíveis
- **Internacional Premium**: Experiências de luxo para destinos especiais

## 🚀 Como Usar

1. **Digite o Destino**: Insira o nome da cidade ou país desejado
2. **Clique em Buscar**: O sistema irá procurar as melhores opções
3. **Analise as Opções**: Compare preços, duração e características
4. **Veja Detalhes**: Confira vantagens e desvantagens de cada opção
5. **Escolha sua Viagem**: Selecione a opção que melhor se adequa ao seu perfil

## 🛠️ Tecnologias Utilizadas

- **React 18**: Framework JavaScript moderno
- **Tailwind CSS**: Framework CSS utilitário
- **shadcn/ui**: Componentes UI profissionais
- **Lucide Icons**: Ícones modernos e consistentes
- **Vite**: Build tool rápido e eficiente

## 📱 Características Técnicas

- **Responsivo**: Adaptado para todos os tamanhos de tela
- **Performance**: Carregamento rápido e interface fluida
- **Acessibilidade**: Componentes acessíveis e navegação por teclado
- **Dados Simulados**: Sistema funcional com dados realistas
- **Busca Inteligente**: Algoritmo que encontra correspondências parciais

## 🎨 Design

O aplicativo utiliza um design moderno com:

- **Gradientes Suaves**: Fundo em gradiente azul para uma aparência elegante
- **Cards Informativos**: Cada opção é apresentada em cards bem estruturados
- **Cores Semânticas**: Verde para preços, azul para informações, vermelho/verde para pros/contras
- **Tipografia Clara**: Hierarquia visual bem definida
- **Espaçamento Consistente**: Layout harmonioso e profissional

## 🔧 Instalação e Desenvolvimento

```bash
# Instalar dependências
npm install

# Executar em modo desenvolvimento
npm run dev

# Build para produção
npm run build

# Preview do build
npm run preview
```

## 📋 Estrutura do Projeto

```
calculadora-viagem/
├── src/
│   ├── components/ui/     # Componentes UI reutilizáveis
│   ├── assets/           # Imagens e recursos estáticos
│   ├── App.jsx          # Componente principal
│   ├── App.css          # Estilos globais
│   └── main.jsx         # Ponto de entrada
├── public/              # Arquivos públicos
└── package.json         # Dependências e scripts
```

## 🌐 Deploy

O aplicativo está pronto para deploy em qualquer plataforma que suporte aplicações React estáticas:

- Vercel
- Netlify
- GitHub Pages
- Firebase Hosting

## 📈 Próximas Funcionalidades

- Integração com APIs reais de viagem
- Sistema de favoritos
- Filtros avançados (preço, duração, tipo)
- Comparação lado a lado
- Histórico de buscas
- Notificações de promoções
- Sistema de avaliações

## 🤝 Contribuição

Este é um projeto demonstrativo. Para melhorias ou sugestões, sinta-se à vontade para contribuir!

## 📄 Licença

Projeto desenvolvido para fins educacionais e demonstrativos.

---

**Desenvolvido com ❤️ para ajudar você a encontrar sua próxima aventura!**

