import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { Search, MapPin, Plane, Hotel, Car, Calendar, DollarSign, ThumbsUp, ThumbsDown, Star } from 'lucide-react'
import './App.css'

// Dados simulados de destinos e opções de viagem
const destinosData = {
  "São Paulo": [
    {
      id: 1,
      destino: "São Paulo",
      tipo: "Nacional",
      precoTotal: 2500,
      duracao: "3 dias",
      transporte: { tipo: "Avião", preco: 800 },
      hospedagem: { tipo: "Hotel 4 estrelas", preco: 1200 },
      atividades: { descricao: "City tour, museus, gastronomia", preco: 500 },
      pros: ["Rica vida cultural", "Excelente gastronomia", "Fácil acesso"],
      contras: ["Trânsito intenso", "Poluição", "Custo de vida alto"],
      avaliacao: 4.2
    },
    {
      id: 2,
      destino: "São Paulo",
      tipo: "Nacional Econômico",
      precoTotal: 1800,
      duracao: "3 dias",
      transporte: { tipo: "Ônibus", preco: 300 },
      hospedagem: { tipo: "Hostel", preco: 600 },
      atividades: { descricao: "Parques, centros culturais gratuitos", preco: 200 },
      pros: ["Opção mais barata", "Muitas atividades gratuitas", "Transporte público"],
      contras: ["Menos conforto", "Mais tempo de viagem", "Hospedagem compartilhada"],
      avaliacao: 3.8
    }
  ],
  "Rio de Janeiro": [
    {
      id: 3,
      destino: "Rio de Janeiro",
      tipo: "Nacional",
      precoTotal: 3200,
      duracao: "4 dias",
      transporte: { tipo: "Avião", preco: 900 },
      hospedagem: { tipo: "Hotel em Copacabana", preco: 1600 },
      atividades: { descricao: "Cristo Redentor, Pão de Açúcar, praias", preco: 700 },
      pros: ["Paisagens deslumbrantes", "Praias famosas", "Pontos turísticos icônicos"],
      contras: ["Segurança em algumas áreas", "Preços altos na zona sul", "Multidões"],
      avaliacao: 4.5
    },
    {
      id: 4,
      destino: "Rio de Janeiro",
      tipo: "Nacional Econômico",
      precoTotal: 2200,
      duracao: "4 dias",
      transporte: { tipo: "Ônibus", preco: 400 },
      hospedagem: { tipo: "Pousada", preco: 800 },
      atividades: { descricao: "Praias gratuitas, trilhas, centros culturais", preco: 300 },
      pros: ["Praias gratuitas", "Trilhas na natureza", "Custo mais baixo"],
      contras: ["Hospedagem mais simples", "Menos comodidades", "Transporte mais longo"],
      avaliacao: 4.0
    }
  ],
  "Buenos Aires": [
    {
      id: 5,
      destino: "Buenos Aires",
      tipo: "Internacional",
      precoTotal: 4500,
      duracao: "5 dias",
      transporte: { tipo: "Avião", preco: 1800 },
      hospedagem: { tipo: "Hotel boutique", preco: 1500 },
      atividades: { descricao: "Tango, museus, gastronomia, compras", preco: 1200 },
      pros: ["Cultura rica", "Arquitetura europeia", "Gastronomia excelente"],
      contras: ["Câmbio instável", "Idioma diferente", "Documentação necessária"],
      avaliacao: 4.3
    },
    {
      id: 6,
      destino: "Buenos Aires",
      tipo: "Internacional Econômico",
      precoTotal: 3200,
      duracao: "5 dias",
      transporte: { tipo: "Ônibus", preco: 800 },
      hospedagem: { tipo: "Hostel", preco: 1000 },
      atividades: { descricao: "Caminhadas, parques, feiras", preco: 600 },
      pros: ["Mais barato", "Experiência autêntica", "Fácil locomoção a pé"],
      contras: ["Viagem mais longa", "Menos conforto", "Hospedagem compartilhada"],
      avaliacao: 3.9
    }
  ],
  "Lisboa": [
    {
      id: 7,
      destino: "Lisboa",
      tipo: "Internacional",
      precoTotal: 8500,
      duracao: "7 dias",
      transporte: { tipo: "Avião", preco: 3500 },
      hospedagem: { tipo: "Hotel histórico", preco: 2800 },
      atividades: { descricao: "Castelos, museus, passeios de tram", preco: 2200 },
      pros: ["História rica", "Arquitetura única", "Gastronomia portuguesa"],
      contras: ["Preço alto", "Voo longo", "Diferença de fuso horário"],
      avaliacao: 4.7
    },
    {
      id: 8,
      destino: "Lisboa",
      tipo: "Internacional Econômico",
      precoTotal: 6200,
      duracao: "7 dias",
      transporte: { tipo: "Avião com escala", preco: 2800 },
      hospedagem: { tipo: "Apartamento", preco: 1800 },
      atividades: { descricao: "Caminhadas, miradouros, mercados", preco: 1600 },
      pros: ["Mais acessível", "Experiência local", "Flexibilidade"],
      contras: ["Voo com escalas", "Menos luxo", "Mais planejamento necessário"],
      avaliacao: 4.2
    }
  ],
  "Tóquio": [
    {
      id: 9,
      destino: "Tóquio",
      tipo: "Internacional Premium",
      precoTotal: 9800,
      duracao: "8 dias",
      transporte: { tipo: "Avião direto", preco: 4200 },
      hospedagem: { tipo: "Hotel moderno", preco: 3200 },
      atividades: { descricao: "Templos, tecnologia, gastronomia japonesa", preco: 2400 },
      pros: ["Cultura única", "Tecnologia avançada", "Gastronomia excepcional"],
      contras: ["Muito caro", "Barreira do idioma", "Diferença cultural grande"],
      avaliacao: 4.8
    }
  ]
}

function App() {
  const [destino, setDestino] = useState('')
  const [resultados, setResultados] = useState([])
  const [carregando, setCarregando] = useState(false)

  const buscarDestino = () => {
    if (!destino.trim()) return
    
    setCarregando(true)
    
    // Simular busca com delay
    setTimeout(() => {
      // Buscar por correspondência exata ou parcial (case insensitive)
      const destinoBusca = destino.trim()
      let opcoes = []
      
      // Procurar por correspondência exata ou parcial
      for (const [chave, valores] of Object.entries(destinosData)) {
        if (chave.toLowerCase().includes(destinoBusca.toLowerCase()) || 
            destinoBusca.toLowerCase().includes(chave.toLowerCase())) {
          opcoes = valores
          break
        }
      }
      
      // Filtrar apenas opções até 10.000 reais
      const opcoesValidas = opcoes.filter(opcao => opcao.precoTotal <= 10000)
      
      setResultados(opcoesValidas)
      setCarregando(false)
    }, 1000)
  }

  const formatarPreco = (preco) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(preco)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              Calculadora de Viagem
            </h1>
            <p className="text-lg text-gray-600">
              Encontre as melhores opções de viagem até R$ 10.000
            </p>
          </div>
        </div>
      </header>

      {/* Search Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Para onde você quer ir?
            </CardTitle>
            <CardDescription>
              Digite o destino desejado e descubra as melhores opções dentro do seu orçamento
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input
                placeholder="Ex: São Paulo, Rio de Janeiro, Buenos Aires..."
                value={destino}
                onChange={(e) => setDestino(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && buscarDestino()}
                className="flex-1"
              />
              <Button 
                onClick={buscarDestino}
                disabled={carregando || !destino.trim()}
                className="px-8"
              >
                {carregando ? 'Buscando...' : 'Buscar'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Results Section */}
      {resultados.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Opções encontradas para {destino}
          </h2>
          
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {resultados.map((opcao) => (
              <Card key={opcao.id} className="shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-blue-600" />
                      {opcao.destino}
                    </CardTitle>
                    <Badge variant={opcao.tipo.includes('Econômico') ? 'secondary' : 'default'}>
                      {opcao.tipo}
                    </Badge>
                  </div>
                  <CardDescription className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {opcao.duracao}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-yellow-500" />
                      {opcao.avaliacao}
                    </span>
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Preço Total */}
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-3xl font-bold text-green-600">
                      {formatarPreco(opcao.precoTotal)}
                    </div>
                    <div className="text-sm text-green-700">Preço total</div>
                  </div>

                  {/* Detalhes dos custos */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm">
                        <Plane className="h-4 w-4" />
                        {opcao.transporte.tipo}
                      </span>
                      <span className="font-medium">{formatarPreco(opcao.transporte.preco)}</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm">
                        <Hotel className="h-4 w-4" />
                        {opcao.hospedagem.tipo}
                      </span>
                      <span className="font-medium">{formatarPreco(opcao.hospedagem.preco)}</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-2 text-sm">
                        <Car className="h-4 w-4" />
                        {opcao.atividades.descricao}
                      </span>
                      <span className="font-medium">{formatarPreco(opcao.atividades.preco)}</span>
                    </div>
                  </div>

                  <Separator />

                  {/* Pros e Contras */}
                  <div className="space-y-3">
                    <div>
                      <h4 className="flex items-center gap-2 font-medium text-green-700 mb-2">
                        <ThumbsUp className="h-4 w-4" />
                        Vantagens
                      </h4>
                      <ul className="text-sm space-y-1">
                        {opcao.pros.map((pro, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="text-green-500 mt-1">•</span>
                            {pro}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="flex items-center gap-2 font-medium text-red-700 mb-2">
                        <ThumbsDown className="h-4 w-4" />
                        Desvantagens
                      </h4>
                      <ul className="text-sm space-y-1">
                        {opcao.contras.map((contra, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="text-red-500 mt-1">•</span>
                            {contra}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <Button className="w-full mt-4">
                    Ver Detalhes
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* No Results */}
      {resultados.length === 0 && destino && !carregando && (
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="text-center py-12">
              <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhuma opção encontrada
              </h3>
              <p className="text-gray-600 mb-4">
                Não encontramos opções para "{destino}" dentro do orçamento de R$ 10.000.
              </p>
              <p className="text-sm text-gray-500">
                Tente buscar por: São Paulo, Rio de Janeiro, Buenos Aires, Lisboa ou Tóquio
              </p>
            </CardContent>
          </Card>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>© 2025 Calculadora de Viagem. Encontre sua próxima aventura!</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

